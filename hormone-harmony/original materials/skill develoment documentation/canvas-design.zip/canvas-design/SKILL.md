# Canvas Design - Logo & Visual Identity Creation

Create professional logo concepts, visual identity systems, and brand marks using design principles and strategic thinking.

## Purpose

Develop logo concepts and visual brand assets that communicate brand positioning, resonate with target audiences, and differentiate from competitors.

## When to Use This Skill

- Creating new logo concepts
- Developing visual brand marks
- Designing wordmarks and lockups
- Creating icon systems
- Developing brand patterns/graphics
- Investor pitch deck visuals
- Brand refresh projects

## Core Principles

### 1. Strategic Logo Design

#### Logo Types
```markdown
## Logo Classification

### WORDMARK
Text-only logo using custom or stylized typography
Examples: Google, Coca-Cola, FedEx
Best for: Unique/memorable company names

### LETTERMARK
Initials or abbreviated name
Examples: IBM, HBO, CNN
Best for: Long company names

### BRAND MARK (Symbol/Icon)
Abstract or pictorial symbol
Examples: Apple, Nike swoosh, Twitter bird
Best for: Recognizable brands, global markets

### COMBINATION MARK
Symbol + wordmark together
Examples: Adidas, Burger King, Lacoste
Best for: New brands building recognition

### EMBLEM
Text inside symbol/badge
Examples: Starbucks, Harley-Davidson, NFL teams
Best for: Traditional, established feel
```

#### Logo Design Process
```markdown
## Step-by-Step Logo Development

### Phase 1: Research & Strategy (1-2 hours)
1. Define brand positioning
   - Who is the target audience?
   - What is the brand personality?
   - What makes it different from competitors?

2. Gather inspiration
   - Analyze competitor logos
   - Research industry trends
   - Explore adjacent categories

3. Define requirements
   - Must work in: color, black/white, small sizes
   - Applications: website, product, print, social
   - Any symbols/metaphors to explore?

### Phase 2: Concept Sketching (2-3 hours)
1. Brainstorm visual concepts (20+ rough sketches)
   - Literal representations
   - Abstract interpretations
   - Typographic solutions
   - Combination approaches

2. Select 3-5 directions
   - Different enough to show range
   - Each tells a different brand story

3. Refine selected concepts
   - Clean up proportions
   - Test at different sizes
   - Try different weights/styles

### Phase 3: Digital Refinement (2-4 hours)
1. Vectorize top concepts
2. Test color variations
3. Create lockup variations
4. Test in real-world applications

### Phase 4: Presentation (1 hour)
1. Show logo in context (mockups)
2. Explain strategic rationale
3. Present variations
4. Gather feedback
```

### 2. Design Principles for Logos

#### Simplicity
```markdown
"A logo should be simple enough to be recalled from memory"

GOOD PRACTICES:
✓ Minimal details (works at small sizes)
✓ Clear, recognizable shapes
✓ Limited color palette (1-3 colors)
✓ Clean lines and forms

BAD PRACTICES:
✗ Too many elements competing
✗ Overly complex illustrations
✗ Too many colors (rainbow effect)
✗ Thin lines that disappear at small sizes
```

#### Memorability
```markdown
"A distinctive logo helps you stand out"

TECHNIQUES:
- Unique shape or form
- Clever negative space (FedEx arrow)
- Unexpected color combination
- Custom typography treatment
- Symbol with meaning

TEST: Can someone sketch it from memory after seeing it once?
```

#### Timelessness
```markdown
"Avoid trends that will date quickly"

TIMELESS QUALITIES:
✓ Classic typography (not trendy fonts)
✓ Simple geometric shapes
✓ Balanced composition
✓ Appropriate symbolism

TREND TRAPS TO AVOID:
✗ Overly stylized/decorative fonts
✗ Gradient mesh effects
✗ 3D/skeuomorphic details
✗ Current design fads (will age poorly)
```

#### Versatility
```markdown
"Logo must work across all applications"

TEST ACROSS:
- Sizes: Favicon (16px) to billboard
- Colors: Full color, single color, black, white, grayscale
- Contexts: Light bg, dark bg, busy bg
- Media: Screen, print, embroidery, signage
```

#### Appropriateness
```markdown
"Logo should fit the brand positioning"

INDUSTRY CONSIDERATIONS:
- Healthcare: Trust, care, professionalism (blues, clean lines)
- Tech: Innovation, modern, forward-thinking (geometric, bold)
- Luxury: Exclusivity, elegance, refinement (serif, simple)
- Children: Playful, friendly, safe (rounded, bright)
- Women's Health: Warm, empathetic, supportive (organic shapes, warm colors)
```

### 3. Typography for Logos

#### Font Selection
```markdown
## Typography Guidelines

### SERIF FONTS
Personality: Traditional, trustworthy, established, sophisticated
Best for: Financial, legal, luxury, heritage brands
Examples: Times, Garamond, Baskerville, Playfair

### SANS-SERIF FONTS
Personality: Modern, clean, approachable, straightforward
Best for: Tech, healthcare, contemporary brands
Examples: Helvetica, Futura, Outfit, Inter

### SCRIPT FONTS
Personality: Elegant, personal, creative, feminine
Best for: Beauty, fashion, handmade, boutique brands
Examples: Pacifico, Dancing Script, Satisfy
(Use sparingly - readability issues at small sizes)

### DISPLAY FONTS
Personality: Unique, bold, attention-grabbing
Best for: Brands wanting strong personality
Warning: Ensure readability and timelessness
```

#### Custom Typography
```markdown
## Creating Custom Wordmarks

### Modifications to Explore:
1. Letter connections (ligatures)
2. Custom terminals (endings of letters)
3. Unique counter shapes (spaces inside letters)
4. Weight adjustments
5. Width variations
6. Cap height modifications

### Tools:
- FontLab (professional font editing)
- Glyphs (Mac font creation)
- Illustrator (vector manipulation)
- Fontself (Illustrator plugin for fonts)
```

### 4. Color Strategy for Logos

#### Color Psychology
```markdown
## Color Meanings in Branding

RED: Energy, passion, urgency, excitement
Use for: Food, retail, entertainment
Examples: Coca-Cola, Target, Netflix

BLUE: Trust, stability, professionalism, calm
Use for: Healthcare, finance, tech, corporate
Examples: Facebook, IBM, PayPal

GREEN: Growth, health, nature, sustainability
Use for: Health, organic, environmental, finance
Examples: Whole Foods, Starbucks, John Deere

PURPLE: Luxury, creativity, wisdom, royalty
Use for: Beauty, luxury, creative services
Examples: Hallmark, Cadbury, Yahoo

ORANGE: Friendly, confident, cheerful, affordable
Use for: Retail, food, youth brands
Examples: Amazon, Nickelodeon, Fanta

BLACK: Sophisticated, premium, modern, powerful
Use for: Luxury, fashion, automotive
Examples: Chanel, Nike, Apple (in certain contexts)

PINK/CORAL: Feminine, compassionate, nurturing, youthful
Use for: Beauty, health, children's products
BUT: Can be stereotypically gendered - use thoughtfully
```

#### Color Combinations
```markdown
## Effective Color Pairing Strategies

### MONOCHROMATIC
Single hue with different shades/tints
Effect: Cohesive, elegant, simple
Example: All blues (navy, sky, light blue)

### COMPLEMENTARY
Opposite colors on color wheel
Effect: High contrast, vibrant, bold
Example: Blue + Orange, Purple + Yellow

### ANALOGOUS
Adjacent colors on color wheel
Effect: Harmonious, natural, calm
Example: Blue + Green + Teal

### NEUTRAL + ACCENT
Gray/Black/White + 1 bright color
Effect: Modern, clean, focused
Example: Black + Sage Green (Hormone Harmony approach)

### WARM PALETTE
Reds, oranges, yellows
Effect: Energetic, friendly, inviting

### COOL PALETTE
Blues, greens, purples
Effect: Calm, professional, trustworthy
```

### 5. Logo Variations & System

#### Essential Logo Files
```markdown
## Complete Logo Package

### FILE FORMATS:
□ Vector files
  - .AI (Adobe Illustrator - editable)
  - .SVG (web, scalable)
  - .EPS (print, universal)
  - .PDF (viewing, print)

□ Raster files
  - .PNG (transparent background, web)
  - .JPG (photos, backgrounds)
  - Multiple sizes: 16px, 32px, 64px, 128px, 256px, 512px, 1024px

### COLOR VARIATIONS:
□ Full color (primary palette)
□ Single color (brand primary)
□ Black (one-color printing)
□ White (dark backgrounds)
□ Grayscale (fax, black & white print)

### LAYOUT VARIATIONS:
□ Horizontal lockup (primary)
□ Vertical lockup (if name is long)
□ Icon only (for favicons, social profiles)
□ Wordmark only (for tight spaces)

### USAGE SPECIFICATIONS:
□ Minimum size requirements
□ Clear space guidelines
□ Approved background colors
□ Usage do's and don'ts
```

### 6. Text-Based Logo Creation (For Immediate Use)

#### Quick Wordmark Development
```markdown
## Creating Professional Text-Only Logos

When you don't have time/budget for custom logo design:

### Step 1: Choose Typography
Select 2-3 professional fonts:
1. Google Fonts (free, web-ready)
   - Outfit (modern, friendly, rounded)
   - Inter (clean, professional, readable)
   - Playfair Display (elegant, sophisticated)
   - Montserrat (geometric, contemporary)

2. Pair fonts strategically:
   - Serif + Sans-serif (classic)
   - Geometric + Humanist (modern)
   - Display + Body (hierarchy)

### Step 2: Style the Text
```css
/* Example: Hormone Harmony Wordmark */
.logo {
  font-family: 'Outfit', sans-serif;
  font-weight: 600; /* Semi-bold for presence */
  font-size: 32px;
  letter-spacing: -0.02em; /* Slightly tighter */
  color: #7B5A7D; /* Brand plum */
}

.logo-accent {
  color: #8BA888; /* Brand sage for "Harmony" */
}
```

### Step 3: Add Subtle Enhancement
- Gradient (subtle, not 90s)
- Letter spacing adjustments
- Multi-line lockup with size contrast
- Underline or accent element
- Icon integrated with type
```

### 7. For Investor Presentations

#### Logo Concepts for Pitch
```markdown
## What Investors Care About in Branding

NOT CRITICAL:
✗ Perfect, final logo (placeholder OK)
✗ Full brand guidelines
✗ Multiple variations

WHAT MATTERS:
✓ Professional appearance (not amateur)
✓ Consistent application across pitch deck
✓ Strategic rationale (why this visual direction)
✓ Differentiation from competitors

### Quick Professional Logo Options:

**Option 1: Text-Only with Color**
- Use brand colors in typography
- Example: "Hormone" in sage, "Harmony" in plum
- Clean, modern, no custom design needed

**Option 2: Initial + Wordmark**
- "HH" monogram + full name
- Simple, recognizable
- Easy to apply across materials

**Option 3: Icon + Text (if you have icon)**
- Simple geometric shape
- Represents hormone balance/cycle
- Paired with clean typography

### Pitch Deck Logo Usage:
- Top left corner on every slide (consistency)
- Footer or bottom corner (alternate placement)
- Cover slide: Larger, prominent
- Content slides: Smaller, unobtrusive
```

## Deliverable Template

### Logo Presentation Format
```markdown
# [Brand Name] Logo Concepts

## Concept 1: [Name]
[Visual mockup]

**Strategic Rationale:**
- [Why this direction]
- [What it communicates]
- [How it differentiates]

**Applications:**
- Website favicon
- Social media profiles
- Product packaging
- Marketing collateral

## Concept 2: [Name]
[Visual mockup]

[Repeat format]

## Recommended Direction:
[Which concept and why]

## Next Steps:
- Refine selected concept
- Create full variation suite
- Develop brand guidelines
- Apply across touchpoints
```

## Quick Logo Checklist

Before finalizing logo:

- [ ] Works in black and white
- [ ] Readable at 16px (favicon size)
- [ ] Looks good reversed (white on dark)
- [ ] Simple enough to be memorable
- [ ] Appropriate for industry/audience
- [ ] Differentiates from competitors
- [ ] Timeless (not trendy)
- [ ] Versatile across applications
- [ ] Vector format available
- [ ] Strategic rationale documented

## Tools & Resources

**Design Tools:**
- Figma (free, collaborative, web-based)
- Adobe Illustrator (industry standard, paid)
- Affinity Designer (affordable alternative)
- Canva Pro (templates, easy to use)

**Inspiration:**
- Logopond.com
- LogoLounge.com
- Brand New (underconsideration.com/brandnew)
- Behance logo projects

**Typography:**
- Google Fonts (free)
- Adobe Fonts (with Creative Cloud)
- Font Squirrel (free commercial fonts)
- MyFonts (premium options)

**Color Tools:**
- Coolors.co (palette generation)
- Adobe Color (color wheel, harmonies)
- Colormind.io (AI-powered palettes)

**Mockup Tools:**
- Placeit.net (instant mockups)
- Smartmockups.com (realistic contexts)
- Figma mockup templates (free)

## Common Logo Mistakes to Avoid

**Design Mistakes:**
✗ Too complex (won't scale down)
✗ Clipart or stock graphics (not unique)
✗ Too many fonts (confusing)
✗ Raster-only files (not scalable)
✗ Poor contrast (not visible)

**Strategic Mistakes:**
✗ Copying competitor styles (no differentiation)
✗ Following trends blindly (will date quickly)
✗ Ignoring target audience (wrong tone)
✗ No usage guidelines (inconsistent application)
✗ Not testing at small sizes (fails in real use)

---

**Use this skill when:** Creating logo concepts, developing visual brand identity, designing wordmarks, preparing investor pitch visuals, or establishing brand recognition system.
