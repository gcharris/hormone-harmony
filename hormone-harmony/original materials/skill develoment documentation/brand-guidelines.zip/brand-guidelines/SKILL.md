# Brand Guidelines Builder

Create comprehensive brand identity systems including visual identity, brand voice, messaging frameworks, and usage guidelines.

## Purpose

Develop cohesive brand guidelines that ensure consistency across all touchpoints while maintaining strategic differentiation and emotional resonance with target audiences.

## When to Use This Skill

- Creating new brand identity systems
- Developing visual identity guidelines
- Establishing brand voice and tone
- Building messaging hierarchies
- Creating logo usage guidelines
- Developing color and typography systems
- Investor presentation branding
- Brand refresh or repositioning projects

## Core Components

### 1. Brand Strategy Foundation

#### Brand Positioning
```markdown
## Brand Positioning Statement

For [target audience]
Who [have this need/problem]
Our [product/service category]
Is [key differentiator]
Unlike [competitors]
We [unique value proposition]

Example:
For women 25-55 experiencing hormone imbalance
Who feel dismissed by traditional healthcare
Our hormone tracking and education platform
Is warm, empathetic, and evidence-based
Unlike clinical medical apps (blue, sterile)
We combine scientific credibility with emotional support
```

#### Brand Personality
```markdown
## Brand Personality Attributes

Select 3-5 attributes that define your brand:

EMOTIONAL ATTRIBUTES:
- Warm vs Professional
- Empathetic vs Authoritative
- Supportive vs Challenging
- Calm vs Energetic
- Approachable vs Aspirational

COMMUNICATION STYLE:
- Conversational vs Formal
- Simple vs Sophisticated
- Direct vs Nuanced
- Playful vs Serious
- Personal vs Universal

CATEGORY POSITIONING:
- Innovative vs Established
- Premium vs Accessible
- Clinical vs Holistic
- Tech-forward vs Human-centered
```

### 2. Visual Identity System

#### Logo Development
```markdown
## Logo Guidelines

### Primary Logo
- Full color version (CMYK, RGB, Hex values)
- When to use: All primary brand applications
- Minimum size: [dimensions]
- Clear space requirements: [spacing rules]

### Logo Variations
- Horizontal lockup
- Vertical lockup (if applicable)
- Icon/symbol only
- Wordmark only
- Monochrome versions (black, white, single color)

### Logo Usage Rules
DO:
✓ Use on brand-approved backgrounds
✓ Maintain minimum clear space
✓ Use provided logo files (never recreate)
✓ Scale proportionally

DON'T:
✗ Rotate, skew, or distort
✗ Change colors outside approved palette
✗ Add effects (shadows, glows, outlines)
✗ Place on busy backgrounds without container
```

#### Color Palette System
```markdown
## Brand Color Palette

### Primary Colors
```css
--brand-primary: #XXXXXX
--brand-primary-light: #XXXXXX
--brand-primary-dark: #XXXXXX
```
Usage: Primary CTAs, key brand moments, headlines
Meaning: [What this color communicates]

### Secondary/Accent Colors
```css
--brand-accent-1: #XXXXXX
--brand-accent-2: #XXXXXX
```
Usage: Supporting elements, variety, highlights
Meaning: [What these colors communicate]

### Neutral Palette
```css
--brand-neutral-dark: #XXXXXX (headings, body text)
--brand-neutral-medium: #XXXXXX (secondary text)
--brand-neutral-light: #XXXXXX (backgrounds, dividers)
```

### Color Psychology
Document why these colors were chosen:
- How do they support brand positioning?
- What emotions do they evoke?
- How do they differentiate from competitors?
```

#### Typography System
```markdown
## Typography Guidelines

### Heading Font
**Font Family:** [Name]
**Weights Available:** 300, 400, 600, 700
**Usage:** Headlines, section titles, key callouts
**Personality:** [What this font communicates]

### Body Font
**Font Family:** [Name]
**Weights Available:** 400, 500, 600
**Usage:** Body copy, captions, supporting text
**Personality:** [Why this font was chosen]

### Type Scale
```css
--font-size-xs: 0.75rem;   /* 12px - Fine print */
--font-size-sm: 0.875rem;  /* 14px - Captions */
--font-size-base: 1rem;    /* 16px - Body text */
--font-size-lg: 1.125rem;  /* 18px - Lead paragraphs */
--font-size-xl: 1.25rem;   /* 20px - Subheadings */
--font-size-2xl: 1.5rem;   /* 24px - Section titles */
--font-size-3xl: 1.875rem; /* 30px - Page titles */
--font-size-4xl: 2.25rem;  /* 36px - Hero headlines */
```

### Pairing Rationale
[Why these fonts work together]
[How they support brand personality]
```

### 3. Brand Voice & Messaging

#### Voice Attributes
```markdown
## Brand Voice Definition

### Core Voice Attributes
Select 4-6 attributes that define how your brand sounds:

TONE SPECTRUM:
- Friendly (not corporate)
- Clear (not jargon-heavy)
- Empathetic (not clinical)
- Confident (not arrogant)
- Educational (not patronizing)
- Warm (not cold)

### Voice Application by Context

**Marketing/Website:**
- [How voice manifests in marketing]
- Example: "You're not alone—and you deserve to be heard"

**Product/UX:**
- [How voice manifests in product]
- Example: Error messages are supportive, not blaming

**Customer Support:**
- [How voice manifests in support]
- Example: Patient, never dismissive

**Social Media:**
- [How voice manifests socially]
- Example: Conversational but never flippant about health
```

#### Messaging Hierarchy
```markdown
## Messaging Framework

### Tagline/Positioning Line
[1 sentence that captures brand essence]
Example: "Find Your Hormone Balance"

### Value Propositions (3-5)
1. [Primary benefit] - [How you deliver it]
2. [Secondary benefit] - [How you deliver it]
3. [Tertiary benefit] - [How you deliver it]

### Proof Points
- [Credibility element 1]
- [Credibility element 2]
- [Credibility element 3]

### Key Messages by Audience

**For Consumers:**
Problem: [Pain point in their words]
Solution: [How you solve it]
Differentiation: [Why choose you]

**For Investors:**
Market Opportunity: [Size and growth]
Competitive Advantage: [Unique position]
Traction/Vision: [Proof and potential]

**For Partners:**
Mutual Value: [What's in it for them]
Differentiation: [Why partner with you]
```

### 4. Application Guidelines

#### Photography Style
```markdown
## Photography Guidelines

### Style Attributes
- Lighting: Natural, warm (not clinical/harsh)
- Settings: Real environments (not studios)
- People: Diverse, authentic (not stock models)
- Mood: Calm, empowering (not anxious)

### Subject Matter
DO USE:
✓ Real product in context
✓ Diverse representation (age, ethnicity)
✓ Lifestyle moments (yoga, journaling, daily life)
✓ Supportive relationships (community, not isolation)

AVOID:
✗ Clinical/medical settings
✗ Sterile, cold imagery
✗ Overly polished/perfect aesthetics
✗ Stock photos that feel inauthentic
```

#### Graphic Elements
```markdown
## Visual Elements System

### Shapes & Patterns
- Rounded corners: [radius specifications]
- Organic shapes vs geometric (which fits brand?)
- Pattern usage (subtle, not overwhelming)

### Iconography
- Style: [outline, filled, illustrated]
- Weight: [stroke width]
- Corner radius: [to match overall system]
- Usage: [when to use icons vs text]

### Spacing & Layout
- Grid system: [column structure]
- Whitespace: [generous vs compact]
- Visual rhythm: [how elements breathe]
```

### 5. Brand Guidelines Document Structure

```markdown
## Complete Brand Guidelines Outline

1. BRAND FOUNDATION
   - Brand story and origin
   - Mission and vision
   - Core values
   - Brand personality
   - Positioning statement

2. VISUAL IDENTITY
   - Logo system and usage
   - Color palette
   - Typography
   - Imagery guidelines
   - Graphic elements

3. BRAND VOICE
   - Voice attributes
   - Tone by context
   - Writing guidelines
   - Vocabulary (words we use/avoid)

4. MESSAGING
   - Tagline
   - Value propositions
   - Elevator pitch
   - Boilerplate (50/100/200 words)

5. APPLICATION EXAMPLES
   - Website examples
   - Social media examples
   - Marketing collateral examples
   - Product UI examples

6. USAGE GUIDELINES
   - What to do / what not to do
   - Approval processes
   - Contact for questions
```

## Workflow: Creating Brand Guidelines

### Phase 1: Research & Strategy (2-3 hours)
1. Analyze target audience deeply
2. Research competitive landscape
3. Define brand positioning
4. Select personality attributes
5. Establish voice guidelines

### Phase 2: Visual Identity (3-4 hours)
1. Develop logo concepts (or document existing)
2. Define color palette with rationale
3. Select typography system
4. Create photography guidelines
5. Design graphic element system

### Phase 3: Documentation (2-3 hours)
1. Write comprehensive guidelines document
2. Create visual examples (do's and don'ts)
3. Develop quick reference guide
4. Design brand guidelines PDF/website

### Phase 4: Implementation (ongoing)
1. Apply guidelines to all touchpoints
2. Train team on brand usage
3. Create asset library
4. Establish approval process

## For Investor Presentations

When creating brand guidelines for investor pitch:

### Focus On:
- **Strategic differentiation** - How brand positioning creates competitive advantage
- **Market resonance** - Evidence that brand connects with target audience
- **Scalability** - How brand system works across products/markets
- **Professional execution** - Demonstrates operational maturity

### Include:
1. Competitive brand positioning map
2. Before/after brand refresh (if applicable)
3. Brand application examples (website, product, marketing)
4. Metrics showing brand performance (awareness, preference)

### Investor-Facing Brand Narrative:
```markdown
Our brand strategy is a competitive advantage because:

1. DIFFERENTIATION: [How our brand stands out]
   - Competitor A uses [approach]
   - Competitor B uses [approach]
   - We use [unique approach] because [strategic rationale]

2. RESONANCE: [How brand connects with audience]
   - User research shows [insight]
   - Our brand attributes align with [audience values]
   - Evidence: [testimonial quotes, engagement metrics]

3. SCALABILITY: [How brand grows with company]
   - Brand system works across [channels/products]
   - Clear guidelines enable [team scaling]
   - Flexible enough for [future expansion]
```

## Deliverables

### Essential Deliverables:
- [ ] Brand positioning statement
- [ ] Logo files (all formats and variations)
- [ ] Color palette (with hex/RGB/CMYK values)
- [ ] Typography specifications
- [ ] Brand voice guidelines
- [ ] Messaging hierarchy
- [ ] Photography guidelines
- [ ] Usage do's and don'ts

### Investor Presentation Deliverables:
- [ ] Brand strategy one-pager
- [ ] Competitive positioning visual
- [ ] Brand application mockups
- [ ] Brand guidelines summary deck

## Tools & Resources

**Color Tools:**
- Coolors.co - Palette generation
- WebAIM Contrast Checker - Accessibility
- Adobe Color - Harmony testing

**Typography Tools:**
- Google Fonts - Free web fonts
- Font Pair - Pairing suggestions
- Type Scale - Size ratio calculator

**Documentation Tools:**
- Figma - Visual guidelines
- Notion - Living document
- Brand.ai - Automated guidelines

## Quality Checklist

Before finalizing brand guidelines:

- [ ] Brand positioning is clear and differentiated
- [ ] Visual identity is consistent and professional
- [ ] Color palette has strategic rationale
- [ ] Typography is readable and on-brand
- [ ] Voice guidelines are actionable (not vague)
- [ ] Usage examples show correct application
- [ ] Guidelines are accessible to entire team
- [ ] Document is well-organized and searchable

---

**Use this skill when:** Creating new brand identity, refreshing existing brand, preparing investor materials, developing brand guidelines document, or establishing visual/verbal identity system.
