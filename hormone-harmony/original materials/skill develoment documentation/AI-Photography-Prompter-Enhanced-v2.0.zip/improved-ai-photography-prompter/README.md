# AI Photography Prompter (Enhanced) 📸

**Version 2.0** | **Professional AI Image Generation Prompts**

Transform your image ideas into professional photography prompts that generate high-quality, commercial-grade images across multiple AI platforms.

## 🚀 Quick Start

Simply describe what you need and Claude will generate optimized prompts:

```
"I need a hero image for a wellness website targeting women 25-45"
```

Claude will automatically:
- Ask clarifying questions for best results
- Generate platform-specific optimized prompts
- Provide multiple variations to test
- Include professional photography guidance

## 🎯 What This Skill Does

### **For Business Users**
- Website hero images and banners
- Product photography prompts
- Social media content creation
- Marketing and advertising materials
- Brand-consistent visual assets

### **For Content Creators**
- Blog post featured images
- Social media posts
- Newsletter graphics
- Course and educational materials
- Personal brand photography

### **For Developers/Agencies**
- Client project imagery
- Prototype and mockup assets
- Presentation visuals
- Portfolio examples
- Stock-style photography

## 🛠 Supported Platforms

| Platform | Optimization Level | Best For |
|----------|-------------------|----------|
| **DALL-E 3** | ⭐⭐⭐⭐⭐ | General use, people, lifestyle |
| **Midjourney** | ⭐⭐⭐⭐⭐ | Artistic quality, consistency |
| **Stable Diffusion** | ⭐⭐⭐⭐⭐ | Fine control, local generation |
| **Gemini Imagen** | ⭐⭐⭐⭐⭐ | Photorealism, diversity |
| **Leonardo AI** | ⭐⭐⭐⭐ | Consistent series, presets |
| **Flux** | ⭐⭐⭐⭐ | Latest model features |

## 📋 Usage Modes

### 🚀 **Express Mode** (Quick Results)
Just describe what you need:
```
"Product shot of a wellness patch being worn naturally"
"Professional headshot for LinkedIn"
"Cozy coffee shop scene for blog header"
```

### 🎯 **Guided Mode** (Recommended)
Claude asks strategic questions:
- Project type and use case
- Subject matter and demographics
- Brand style and mood
- Technical requirements
- Platform preferences

### 🔧 **Expert Mode** (Advanced Users)
- Custom composition techniques
- Specific camera/lens references
- Advanced lighting setups
- Platform-specific parameters
- Technical photography terms

## 💡 Example Workflows

### Website Hero Image
```
Input: "I need a hero image for a hormone health website"

Output: Multiple optimized prompts including:
- DALL-E 3 natural language version
- Midjourney with parameters
- Stable Diffusion with weights
- Composition and lighting guidance
- Variations for A/B testing
```

### Product Photography
```
Input: "Show a wellness patch being worn naturally"

Output: Specialized prompts featuring:
- Authentic lifestyle context
- Sharp product focus
- Natural lighting setups
- Multiple angle options
- Platform-specific optimization
```

### Social Media Content
```
Input: "Instagram post about morning wellness routine"

Output: Square format prompts with:
- Mobile-optimized composition
- Vibrant, engaging visuals
- Text-overlay considerations
- Trend-aware styling
- Platform best practices
```

## 🎨 Photography Expertise Built-In

### **Composition Mastery**
- Rule of thirds optimization
- Leading lines and depth
- Negative space for text
- Symmetrical and asymmetrical balance
- Perspective and angles

### **Lighting Excellence**
- Golden hour warmth
- Natural window light
- Studio lighting setups
- Dramatic and soft options
- Mood-specific illumination

### **Style Adaptation**
- Editorial and commercial styles
- Lifestyle and documentary approaches
- Fashion and portrait techniques
- Product and architectural methods
- Cultural and demographic sensitivity

## 🔄 Iterative Improvement

The skill helps you refine results:
- **First attempt not perfect?** Get specific adjustment suggestions
- **Need style changes?** Targeted modifications for mood and aesthetic
- **Platform issues?** Alternative syntax and approaches
- **Quality concerns?** Technical parameter optimization

## 📊 Quality Standards

Every prompt includes:
- ✅ Professional resolution specifications
- ✅ Commercial-quality descriptors
- ✅ Authentic representation guidelines
- ✅ Platform-optimized syntax
- ✅ Technical photography terms
- ✅ Composition best practices

## 🎯 Professional Results

This skill is designed for:
- **Marketing teams** creating brand visuals
- **Content creators** needing consistent quality
- **Agencies** serving diverse clients
- **Entrepreneurs** building their brand
- **Developers** needing placeholder content that doesn't look like placeholders

## 🚀 Getting Started

1. **Describe your image needs** in natural language
2. **Answer Claude's clarifying questions** for best results
3. **Get optimized prompts** for your chosen AI platform
4. **Generate images** using the provided prompts
5. **Iterate and refine** with Claude's guidance

## 📈 Advanced Features

### **Brand Consistency**
- Style templates for consistent series
- Color palette integration
- Mood and tone matching
- Cultural sensitivity guidance

### **Technical Optimization**
- Platform-specific parameter tuning
- Aspect ratio optimization
- Resolution and quality controls
- Composition rule application

### **Creative Enhancement**
- Seasonal adaptations
- Trend integration
- Artistic reference inclusion
- Mood board inspiration

## 💬 Example Conversations

**Simple Request:**
```
You: "I need a professional headshot"
Claude: "I'll help you create the perfect headshot prompt. A few quick questions..."
```

**Complex Project:**
```
You: "I'm launching a wellness app and need a complete photo set"
Claude: "Excellent! Let's plan a cohesive visual identity. I'll help you create..."
```

**Platform-Specific:**
```
You: "Optimize this prompt for Midjourney's latest version"
Claude: "Here's your prompt with v6 optimization and parameter tuning..."
```

## 🎯 Success Stories

This skill generates prompts that create:
- **Website heroes** that convert visitors
- **Product shots** that drive sales
- **Social content** that engages audiences
- **Marketing materials** that represent brands professionally
- **Stock-quality images** for any purpose

---

**Ready to create professional AI photography prompts?** Just start describing what you need, and Claude will guide you to the perfect prompt for stunning results.
