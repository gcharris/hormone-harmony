#!/usr/bin/env node

/**
 * AI Photography Prompter (Enhanced) - Automated Image Generation
 * 
 * Version: 2.0
 * Author: Claude Code + Enhanced by Claude
 * 
 * Features:
 * - Multi-platform prompt optimization
 * - Interactive questionnaire mode
 * - Template library with professional prompts
 * - Batch generation for consistent series
 * - Quality validation and improvement suggestions
 * 
 * Usage:
 *   node generate-image.js "your prompt here"
 *   node generate-image.js --interactive
 *   node generate-image.js --template <name>
 *   node generate-image.js --batch <file.json>
 */

import { GoogleGenerativeAI } from '@google/generative-ai';
import dotenv from 'dotenv';
import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';
import readline from 'readline';

// ES module setup
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Load environment variables
dotenv.config();

// Enhanced configuration
const CONFIG = {
  apiKey: process.env.GEMINI_API_KEY,
  outputDir: process.env.IMAGE_OUTPUT_DIR || './generated-images',
  promptsDir: process.env.PROMPTS_DIR || './saved-prompts',
  templatesDir: process.env.TEMPLATES_DIR || './templates',
  imageFormat: process.env.IMAGE_FORMAT || 'png',
  imageQuality: process.env.IMAGE_QUALITY || 'high',
  model: 'gemini-2.0-flash-exp',
  maxPromptLength: 2000,
  platforms: ['dalle3', 'midjourney', 'stable-diffusion', 'gemini-imagen', 'leonardo', 'flux']
};

// Validate configuration
if (!CONFIG.apiKey || CONFIG.apiKey === 'your-api-key-here') {
  console.error('❌ Error: GEMINI_API_KEY not set in .env file');
  console.error('Get your API key from: https://makersuite.google.com/app/apikey');
  process.exit(1);
}

// Initialize Gemini AI
const genAI = new GoogleGenerativeAI(CONFIG.apiKey);

/**
 * Enhanced prompt templates with professional photography knowledge
 */
const PROMPT_TEMPLATES = {
  'website-hero': {
    description: 'Website hero/banner images with text space',
    prompt: `Professional lifestyle photography of a diverse person in their 30s in an aspirational but realistic setting. Natural golden hour lighting creates a warm, inviting atmosphere. The composition uses negative space on the right side for text overlay, following the rule of thirds. Shot with shallow depth of field creating beautiful background blur. The mood is [MOOD], [STYLE], and authentic. High resolution commercial photography, suitable for website headers. Aspect ratio 16:9.`,
    variables: ['MOOD', 'STYLE'],
    aspectRatio: '16:9'
  },
  
  'product-lifestyle': {
    description: 'Product shown in authentic lifestyle context',
    prompt: `Professional lifestyle product photography showing [PRODUCT] being used naturally by a person in their 30s in a realistic setting. The scene takes place in a [SETTING] with soft, natural lighting creating an authentic atmosphere. Focus is tack sharp on the product while maintaining context. The moment feels genuine and unposed. Shot with professional composition and [LIGHTING] lighting. High-end commercial product photography, magazine quality.`,
    variables: ['PRODUCT', 'SETTING', 'LIGHTING'],
    aspectRatio: '4:5'
  },
  
  'testimonial-portrait': {
    description: 'Professional portraits for testimonials',
    prompt: `Professional environmental portrait of a [DEMOGRAPHIC] in their natural context. They have a genuine, confident expression and are looking directly at the camera with an approachable smile. The background is softly blurred showing their environment. Natural lighting creates flattering, warm illumination. The mood is trustworthy, professional, and relatable. Shot with medium aperture for gentle background separation. High resolution portrait photography in editorial style.`,
    variables: ['DEMOGRAPHIC'],
    aspectRatio: '1:1'
  },
  
  'social-media': {
    description: 'Engaging social media content',
    prompt: `Vibrant lifestyle photography optimized for social media showing [SUBJECT] in an engaging, authentic moment. The scene has bright, appealing colors and high visual impact. Composition is centered and mobile-optimized with negative space at top for text overlay. The mood is energetic, positive, and scroll-stopping. Shot with natural lighting and shallow depth of field. High resolution, social media ready, square format.`,
    variables: ['SUBJECT'],
    aspectRatio: '1:1'
  },
  
  'before-after': {
    description: 'Transformation story visualization',
    prompt: `Split-screen lifestyle photography showing transformation. LEFT SIDE: [BEFORE_SCENE] with cooler, muted lighting representing the problem state. RIGHT SIDE: [AFTER_SCENE] with warm, golden lighting showing the solution state. The contrast should tell a clear story of improvement. Professional editorial photography with cinematic composition. The same person appears in both sides showing genuine transformation. Magazine-quality storytelling photography.`,
    variables: ['BEFORE_SCENE', 'AFTER_SCENE'],
    aspectRatio: '16:9'
  },
  
  'overhead-flatlay': {
    description: 'Styled flat-lay arrangements',
    prompt: `Professional overhead flat-lay photography of [ITEMS] arranged on a clean [SURFACE]. The composition is carefully styled but feels authentic, not overly staged. Natural window light creates soft shadows and highlights textures. The color palette is [COLOR_PALETTE]. Shot from directly above with perfect symmetry and negative space for text. High resolution, editorial-quality commercial photography showing the complete ecosystem.`,
    variables: ['ITEMS', 'SURFACE', 'COLOR_PALETTE'],
    aspectRatio: '1:1'
  }
};

/**
 * Platform-specific optimization rules
 */
const PLATFORM_OPTIMIZATIONS = {
  'dalle3': {
    prefix: 'A professional photograph of',
    style: 'natural language, descriptive sentences',
    qualityTerms: ['high resolution', 'commercial quality', 'professional photography'],
    avoid: ['over-specification', 'technical camera terms', 'artistic parameters']
  },
  
  'midjourney': {
    prefix: 'professional photography,',
    style: 'comma-separated descriptors with parameters',
    parameters: ['--ar', '--s', '--v 6'],
    qualityTerms: ['shot on Canon EOS R5', '85mm f/1.4', 'commercial quality'],
    avoid: ['natural sentences', 'overly long descriptions']
  },
  
  'stable-diffusion': {
    prefix: '(professional photography:1.3),',
    style: 'weighted terms with parentheses',
    qualityTerms: ['8k uhd', 'dslr', 'professional lighting', '(high quality:1.2)'],
    negativePrompt: 'blurry, low quality, amateur, harsh lighting, unnatural pose, watermark, text',
    avoid: ['natural language flow']
  },
  
  'gemini-imagen': {
    prefix: 'A high-quality professional photograph showing',
    style: 'natural language emphasizing authenticity',
    qualityTerms: ['authentic', 'diverse representation', 'photorealistic', 'professional quality'],
    avoid: ['potentially sensitive content', 'overly stylized requests']
  },
  
  'leonardo': {
    prefix: 'Professional commercial photography,',
    style: 'descriptive with preset recommendations',
    qualityTerms: ['photorealistic', 'high detail', '8k resolution'],
    presets: ['PhotoReal with Alchemy enabled'],
    avoid: ['conflicting style terms']
  },
  
  'flux': {
    prefix: 'Professional photography,',
    style: 'balanced technical and creative terms',
    qualityTerms: ['high resolution', 'professional quality', 'realistic lighting'],
    avoid: ['legacy syntax', 'outdated parameters']
  }
};

/**
 * Ensure all required directories exist
 */
async function ensureDirectories() {
  const dirs = [CONFIG.outputDir, CONFIG.promptsDir, CONFIG.templatesDir];
  
  for (const dir of dirs) {
    try {
      await fs.mkdir(dir, { recursive: true });
    } catch (error) {
      console.error(`❌ Failed to create directory ${dir}:`, error.message);
    }
  }
}

/**
 * Generate optimized prompts for multiple platforms
 */
async function generateOptimizedPrompts(basePrompt, platforms = ['dalle3', 'midjourney']) {
  const results = {};
  
  for (const platform of platforms) {
    if (!PLATFORM_OPTIMIZATIONS[platform]) {
      console.warn(`⚠️  Unknown platform: ${platform}`);
      continue;
    }
    
    const optimization = PLATFORM_OPTIMIZATIONS[platform];
    let optimizedPrompt = basePrompt;
    
    // Apply platform-specific formatting
    if (platform === 'midjourney') {
      // Convert to comma-separated format
      optimizedPrompt = optimizedPrompt
        .replace(/\. /g, ', ')
        .replace(/\.$/, '');
      
      // Add parameters
      optimizedPrompt += ' --ar 16:9 --s 250 --v 6';
      
    } else if (platform === 'stable-diffusion') {
      // Add weights to key terms
      optimizedPrompt = optimizedPrompt
        .replace(/professional photography/g, '(professional photography:1.3)')
        .replace(/high quality/g, '(high quality:1.2)')
        .replace(/natural lighting/g, '(natural lighting:1.1)');
      
      // Add negative prompt
      results[`${platform}_negative`] = optimization.negativePrompt;
      
    } else if (platform === 'dalle3' || platform === 'gemini-imagen') {
      // Ensure natural language flow
      if (!optimizedPrompt.startsWith('A ')) {
        optimizedPrompt = optimization.prefix + ' ' + optimizedPrompt;
      }
    }
    
    // Add quality terms
    if (!optimization.qualityTerms.some(term => optimizedPrompt.includes(term))) {
      optimizedPrompt += '. ' + optimization.qualityTerms.slice(0, 2).join(', ') + '.';
    }
    
    results[platform] = optimizedPrompt;
  }
  
  return results;
}

/**
 * Interactive questionnaire mode
 */
async function interactiveMode() {
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  });

  const question = (prompt) => new Promise((resolve) => rl.question(prompt, resolve));

  console.log('\n🎨 AI Photography Prompter - Enhanced Interactive Mode\n');
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');

  try {
    // Core questions
    const projectType = await question('1️⃣  Project type (website-hero/product/social/testimonial/other): ');
    const subject = await question('2️⃣  Subject matter (describe what to photograph): ');
    const demographics = await question('3️⃣  Demographics (age, ethnicity, gender - be specific for representation): ');
    const setting = await question('4️⃣  Setting/environment (where does this take place): ');
    const mood = await question('5️⃣  Mood/style (warm/professional/energetic/calm/authentic): ');
    const platform = await question('6️⃣  Primary AI platform (dalle3/midjourney/stable-diffusion/gemini-imagen): ');
    const orientation = await question('7️⃣  Orientation (landscape/portrait/square): ');
    const specialReqs = await question('8️⃣  Special requirements (text space/colors/specific objects): ');

    console.log('\n✨ Generating your optimized prompts...\n');

    // Map orientation to aspect ratio
    const aspectRatios = {
      landscape: '16:9',
      portrait: '4:5', 
      square: '1:1'
    };

    // Build sophisticated prompt
    const basePrompt = `
Professional ${mood} photography of ${demographics} ${subject} in ${setting}.
The scene has natural lighting creating a ${mood} atmosphere.
The composition is ${orientation} format and includes ${specialReqs || 'professional styling'}.
This is high-quality commercial photography with authentic representation.
Shot in contemporary editorial style with professional equipment.
    `.trim();

    // Generate platform-optimized versions
    const platforms = [platform];
    if (platform !== 'dalle3') platforms.push('dalle3'); // Always include DALL-E as backup
    
    const optimizedPrompts = await generateOptimizedPrompts(basePrompt, platforms);

    // Display results
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('🎯 YOUR OPTIMIZED PROMPTS');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');

    for (const [platformName, prompt] of Object.entries(optimizedPrompts)) {
      if (platformName.includes('negative')) continue;
      
      console.log(`📱 ${platformName.toUpperCase()}`);
      console.log('─'.repeat(50));
      console.log(`${prompt}\n`);
      
      if (optimizedPrompts[`${platformName}_negative`]) {
        console.log(`❌ Negative prompt: ${optimizedPrompts[`${platformName}_negative`]}\n`);
      }
    }

    // Save prompts
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, -5);
    const filename = `interactive_session_${timestamp}.json`;
    const sessionData = {
      timestamp,
      inputs: { projectType, subject, demographics, setting, mood, platform, orientation, specialReqs },
      prompts: optimizedPrompts
    };

    await fs.writeFile(
      path.join(CONFIG.promptsDir, filename),
      JSON.stringify(sessionData, null, 2)
    );

    console.log(`✅ Session saved to: ${CONFIG.promptsDir}/${filename}`);
    console.log('\n💡 Tips for best results:');
    console.log('   • Try multiple variations with small changes');
    console.log('   • Adjust lighting terms if mood is off');
    console.log('   • Specify composition if framing needs work');
    console.log('   • Add "authentic" or "natural" if results look too posed\n');

    rl.close();
    return optimizedPrompts;

  } catch (error) {
    rl.close();
    throw error;
  }
}

/**
 * Use a template with variable substitution
 */
async function useTemplate(templateName, variables = {}) {
  if (!PROMPT_TEMPLATES[templateName]) {
    console.error(`❌ Unknown template: ${templateName}`);
    console.log('\n📚 Available templates:');
    Object.entries(PROMPT_TEMPLATES).forEach(([name, template]) => {
      console.log(`   ${name}: ${template.description}`);
    });
    process.exit(1);
  }

  const template = PROMPT_TEMPLATES[templateName];
  let prompt = template.prompt;

  // Substitute variables
  for (const variable of template.variables || []) {
    if (variables[variable]) {
      prompt = prompt.replace(new RegExp(`\\[${variable}\\]`, 'g'), variables[variable]);
    } else {
      // Provide defaults or ask for input
      const defaultValues = {
        'MOOD': 'warm and professional',
        'STYLE': 'authentic lifestyle',
        'PRODUCT': 'wellness product',
        'SETTING': 'natural home environment',
        'LIGHTING': 'soft natural',
        'DEMOGRAPHIC': 'diverse professional in their 30s',
        'SUBJECT': 'person in daily routine',
        'BEFORE_SCENE': 'person looking stressed at cluttered desk',
        'AFTER_SCENE': 'same person looking confident in organized space',
        'ITEMS': 'wellness products and lifestyle items',
        'SURFACE': 'white marble surface',
        'COLOR_PALETTE': 'warm neutrals with sage green accents'
      };
      
      prompt = prompt.replace(new RegExp(`\\[${variable}\\]`, 'g'), defaultValues[variable] || variable.toLowerCase());
    }
  }

  console.log(`\n📋 Using template: ${templateName}`);
  console.log(`📐 Recommended aspect ratio: ${template.aspectRatio}`);
  console.log(`📝 ${template.description}\n`);

  return prompt;
}

/**
 * Batch generate prompts from JSON configuration
 */
async function batchGenerate(configFile) {
  try {
    const configData = await fs.readFile(configFile, 'utf8');
    const config = JSON.parse(configData);
    
    console.log(`\n📦 Batch generating ${config.prompts?.length || 0} prompts...\n`);
    
    const results = [];
    
    for (let i = 0; i < config.prompts.length; i++) {
      const promptConfig = config.prompts[i];
      console.log(`🔄 Processing prompt ${i + 1}/${config.prompts.length}: ${promptConfig.name || 'Unnamed'}`);
      
      let basePrompt;
      
      if (promptConfig.template) {
        basePrompt = await useTemplate(promptConfig.template, promptConfig.variables || {});
      } else {
        basePrompt = promptConfig.prompt;
      }
      
      const optimizedPrompts = await generateOptimizedPrompts(
        basePrompt, 
        promptConfig.platforms || ['dalle3', 'midjourney']
      );
      
      results.push({
        name: promptConfig.name || `prompt_${i + 1}`,
        basePrompt,
        optimizedPrompts
      });
    }
    
    // Save batch results
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, -5);
    const outputFile = path.join(CONFIG.promptsDir, `batch_${timestamp}.json`);
    
    await fs.writeFile(outputFile, JSON.stringify({ 
      batchConfig: config,
      results,
      generatedAt: new Date().toISOString()
    }, null, 2));
    
    console.log(`\n✅ Batch complete! Results saved to: ${outputFile}`);
    return results;
    
  } catch (error) {
    console.error('❌ Batch generation failed:', error.message);
    process.exit(1);
  }
}

/**
 * Main function
 */
async function main() {
  const args = process.argv.slice(2);

  console.log('\n🎨 AI Photography Prompter (Enhanced) v2.0');
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');

  await ensureDirectories();

  // Determine mode
  if (args.includes('--interactive') || args.includes('-i')) {
    await interactiveMode();
    
  } else if (args.includes('--template') || args.includes('-t')) {
    const templateIndex = args.findIndex(arg => arg === '--template' || arg === '-t');
    const templateName = args[templateIndex + 1];
    
    if (!templateName) {
      console.error('❌ Please specify a template name');
      console.log('\nUsage: node generate-image.js --template <name>');
      console.log('\n📚 Available templates:');
      Object.entries(PROMPT_TEMPLATES).forEach(([name, template]) => {
        console.log(`   ${name}: ${template.description}`);
      });
      process.exit(1);
    }
    
    const basePrompt = await useTemplate(templateName);
    const optimizedPrompts = await generateOptimizedPrompts(basePrompt, ['dalle3', 'midjourney', 'stable-diffusion']);
    
    console.log('🎯 Generated prompts:');
    Object.entries(optimizedPrompts).forEach(([platform, prompt]) => {
      console.log(`\n📱 ${platform.toUpperCase()}:`);
      console.log(prompt);
    });
    
  } else if (args.includes('--batch') || args.includes('-b')) {
    const batchIndex = args.findIndex(arg => arg === '--batch' || arg === '-b');
    const configFile = args[batchIndex + 1];
    
    if (!configFile) {
      console.error('❌ Please specify a batch configuration file');
      console.log('\nUsage: node generate-image.js --batch <config.json>');
      process.exit(1);
    }
    
    await batchGenerate(configFile);
    
  } else if (args.length > 0 && !args[0].startsWith('--')) {
    // Direct prompt mode with platform optimization
    const prompt = args.join(' ');
    console.log(`📝 Optimizing prompt: "${prompt}"\n`);
    
    const optimizedPrompts = await generateOptimizedPrompts(prompt, ['dalle3', 'midjourney', 'stable-diffusion', 'gemini-imagen']);
    
    console.log('🎯 Platform-optimized versions:');
    Object.entries(optimizedPrompts).forEach(([platform, optimizedPrompt]) => {
      if (platform.includes('negative')) return;
      
      console.log(`\n📱 ${platform.toUpperCase()}:`);
      console.log(`${optimizedPrompt}`);
      
      if (optimizedPrompts[`${platform}_negative`]) {
        console.log(`❌ Negative: ${optimizedPrompts[`${platform}_negative`]}`);
      }
    });
    
    // Save the session
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, -5);
    await fs.writeFile(
      path.join(CONFIG.promptsDir, `quick_prompt_${timestamp}.txt`),
      Object.entries(optimizedPrompts).map(([platform, prompt]) => 
        `=== ${platform.toUpperCase()} ===\n${prompt}\n`
      ).join('\n')
    );
    
  } else {
    // Show usage
    console.log('🚀 Usage Options:');
    console.log('  node generate-image.js "your custom prompt"');
    console.log('  node generate-image.js --interactive');
    console.log('  node generate-image.js --template <name>');
    console.log('  node generate-image.js --batch <config.json>');
    console.log('\n📚 Templates:', Object.keys(PROMPT_TEMPLATES).join(', '));
    console.log('\n🎯 Supported platforms:', CONFIG.platforms.join(', '));
    console.log('\n💡 Examples:');
    console.log('  node generate-image.js --template website-hero');
    console.log('  node generate-image.js --interactive');
    console.log('  node generate-image.js "professional photo of a woman doing yoga"\n');
  }
}

// Run the script
main().catch(error => {
  console.error('\n❌ Fatal error:', error.message);
  process.exit(1);
});
