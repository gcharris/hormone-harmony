# AI Photography Prompter (Enhanced)

**Version:** 2.0  
**Author:** Claude Code + Claude Enhancement  
**Purpose:** Generate optimized photography prompts for AI image generation with professional results  
**Platforms:** DALL-E 3, Midjourney, Stable Diffusion, Gemini Imagen, Leonardo AI, Flux  

## Overview

This skill transforms your image ideas into professional photography prompts that generate high-quality, commercial-grade images across multiple AI platforms. Whether you need website heroes, product shots, lifestyle photography, or marketing materials, this skill applies photography expertise to create prompts that work.

## When to Use This Skill

Claude will automatically apply this skill when you:
- Ask for help with AI image generation prompts
- Need photography for commercial or marketing use
- Request help with image composition or lighting
- Want to optimize prompts for specific AI platforms
- Need consistent visual style across multiple images

## Core Capabilities

### 🎯 **Smart Prompt Generation**
- Analyzes your needs and generates optimized prompts
- Adapts language for different AI platforms
- Incorporates professional photography principles
- Provides multiple variations for testing

### 📸 **Photography Expertise**
- Composition techniques (rule of thirds, leading lines, depth of field)
- Lighting mastery (golden hour, natural light, studio setups)
- Style guidance (editorial, lifestyle, commercial, product)
- Technical optimization (camera settings, quality modifiers)

### 🔄 **Multi-Platform Support**
- **DALL-E 3**: Natural language optimization
- **Midjourney**: Parameter syntax and artistic references
- **Stable Diffusion**: Weighted terms and negative prompts
- **Gemini Imagen**: Photorealism and diversity focus
- **Leonardo AI**: Preset integration and consistency
- **Flux**: Latest model optimization

### 🎨 **Style Systems**
- Brand-appropriate imagery
- Mood and emotional tone control
- Color palette specification
- Cultural sensitivity and representation

## User Interaction Flow

### Quick Start (Express Mode)
For experienced users who know what they want:

```
Just describe your image needs and I'll generate optimized prompts immediately.

Example: "I need a hero image for a wellness website targeting women 25-45"
```

### Guided Mode (Recommended)
For best results, I'll ask strategic questions:

1. **Project Context**: Website, social media, print, etc.
2. **Subject & Scene**: What should be photographed
3. **Brand Style**: Professional, warm, modern, etc.
4. **Technical Specs**: Platform, orientation, special requirements
5. **Target Audience**: Demographics and use case

### Expert Mode
For advanced users who want full control:
- Platform-specific syntax
- Advanced composition techniques
- Technical photography parameters
- Style reference integration

## Photography Framework

### Prompt Anatomy
```
[SUBJECT] + [ACTION/POSE] + [SETTING] + [LIGHTING] + [COMPOSITION] + [STYLE] + [MOOD] + [TECHNICAL]
```

### Essential Elements

**Subject Description**
- Demographics (age, ethnicity, gender)
- Clothing and styling
- Expression and emotion
- Activity or pose

**Environmental Context**
- Location and setting
- Props and objects
- Background elements
- Spatial relationships

**Technical Execution**
- Lighting type and direction
- Composition technique
- Camera angle and perspective
- Depth of field control

**Aesthetic Control**
- Photography style reference
- Color palette and mood
- Emotional tone
- Brand alignment

## Platform Optimization

### DALL-E 3
```markdown
**Strengths**: Natural language, photorealistic people, lifestyle scenes
**Format**: Descriptive sentences with clear style references
**Example**: 
"A professional photograph of a confident woman in her 30s working at a modern office desk. 
Natural window light creates a warm, professional atmosphere. The composition uses the rule 
of thirds with shallow depth of field. Shot in contemporary lifestyle editorial style. 
High resolution, commercial quality."
```

### Midjourney
```markdown
**Strengths**: Artistic quality, consistent aesthetics, photography simulation
**Format**: Comma-separated descriptors with parameters
**Example**:
"professional lifestyle photography, woman in 30s, modern office setting, natural window 
lighting, rule of thirds composition, shallow depth of field, contemporary editorial style, 
shot on Canon EOS R5, 85mm f/1.4, commercial quality --ar 16:9 --s 250 --v 6"
```

### Stable Diffusion
```markdown
**Strengths**: Fine control, local generation, customization
**Format**: Weighted terms with negative prompts
**Example**:
"Prompt: (professional lifestyle photography:1.3), woman in her 30s, modern office, 
(natural lighting:1.2), rule of thirds, (commercial quality:1.1), 8k uhd, dslr

Negative: blurry, amateur, harsh lighting, unnatural pose, watermark, text"
```

### Gemini Imagen
```markdown
**Strengths**: Photorealism, diversity, safety-conscious generation
**Format**: Natural language with emphasis on authenticity
**Example**:
"A high-quality professional photograph showing a woman in her 30s in a modern office 
environment. The scene is lit with natural window light creating a warm, professional 
atmosphere. The composition follows the rule of thirds with shallow depth of field. 
This is authentic lifestyle photography emphasizing diversity and real workplace moments."
```

## Template Library

### Website Hero Images
```
Professional lifestyle photography of [diverse person] in [aspirational setting], 
natural golden hour lighting, [composition technique], negative space for text overlay, 
[brand mood], high resolution commercial photography, [orientation]
```

### Product Photography
```
Professional product photography of [product] in [natural context], [person] using product 
naturally, soft natural lighting, tack sharp focus on product, shallow depth of field, 
authentic lifestyle moment, commercial quality, [specific requirements]
```

### Testimonial/Portrait
```
Professional environmental portrait of [person description] in [their context], 
genuine expression, natural lighting, [composition style], approachable and trustworthy mood, 
authentic representation, high resolution portrait photography
```

### Before/After Concepts
```
Split-screen photography showing [transformation concept], LEFT: [before state] with 
[mood/lighting], RIGHT: [after state] with [contrasting mood/lighting], 
cinematic composition, clear visual narrative, [brand alignment]
```

## Quality Standards

### Professional Requirements
- High resolution (8K/4K specified)
- Commercial quality lighting
- Authentic, unposed moments
- Diverse representation
- Brand-appropriate styling

### Composition Excellence
- Strategic negative space
- Intentional depth of field
- Professional framing
- Platform-optimized ratios

### Technical Standards
- Platform-specific syntax
- Quality modifiers included
- Lighting specifications
- Camera/lens references

## Advanced Techniques

### Creating Consistent Series
Use a base style template across multiple prompts:

```
Base Style: "Shot on Canon EOS R5 with 85mm f/1.4 lens, natural golden hour lighting, 
warm color grading, shallow depth of field, authentic lifestyle editorial photography, 
commercial quality"

Apply to different scenes:
- Scene A: [specific subject] + [base style]
- Scene B: [different subject] + [base style]
```

### Seasonal Adaptations
- **Spring**: Fresh green tones, renewal mood, soft morning light
- **Summer**: Golden warmth, vibrant energy, natural brightness
- **Fall**: Warm amber tones, cozy atmosphere, afternoon light
- **Winter**: Cool undertones, intimate lighting, peaceful mood

### Background Considerations
For easy editing:
```
"clean background for easy extraction, good edge definition, 
clear separation between subject and background"
```

### Multi-Image Compositions
For composite work:
```
"isolated elements on neutral background, consistent lighting across elements"
```

## Troubleshooting Guide

### Common Issues & Solutions

**Unrealistic People**
- Add "authentic lifestyle photography"
- Specify "natural unposed moment"
- Use "real person, not model-like"
- Lower stylization in Midjourney

**Poor Composition**
- Specify composition technique
- Add "rule of thirds" or "centered symmetrical"
- Include "negative space for text overlay"

**Wrong Lighting**
- Replace vague terms: "bright" → "golden hour natural light"
- Be specific: "soft window light" vs "harsh studio lighting"
- Add mood context: "warm and inviting" or "dramatic shadows"

**Style Mismatch**
- Include photography style references
- Add "editorial", "commercial", or "lifestyle"
- Specify camera/lens for technical feel

**Low Quality Results**
- Emphasize "professional", "high resolution", "commercial quality"
- Add platform-specific quality terms
- Include camera specifications

## Workflow Examples

### Example 1: Wellness Website Hero

**Input**: "I need a hero image for a hormone health website targeting women 25-45."

**Claude Response**:
```
I'll create several optimized prompts for your wellness website hero image.

**Option 1 - Morning Wellness Routine** (16:9 landscape)

DALL-E 3:
"A professional lifestyle photograph of a diverse woman in her mid-30s practicing gentle 
morning yoga on a sunlit wooden floor. Natural golden hour light streams through large 
windows, creating a warm, peaceful atmosphere. The composition uses negative space on the 
right side for text overlay, with the subject positioned following the rule of thirds. 
Shot with shallow depth of field, the background is softly blurred. The mood is calm, 
empowering, and authentic. High resolution commercial photography, warm tones, 
wellness editorial style."

Midjourney:
"professional lifestyle photography, woman in her 30s, morning yoga practice, sunlit 
wooden floor, large windows, golden hour lighting, warm peaceful atmosphere, negative 
space right side, rule of thirds, shallow depth of field, calm empowering mood, 
authentic moment, shot on Canon EOS R5, 85mm f/1.4, wellness editorial 
--ar 16:9 --s 200 --v 6"

**Why these work:**
- Natural, authentic moments (not overly posed)
- Warm lighting matches wellness brand feel
- Diverse representation (age-appropriate for target audience)
- Negative space designed for text overlay
- Professional quality suitable for hero placement

**Variations to try:**
- Self-care journaling scene
- Healthy cooking moment
- Peaceful meditation
- Natural outdoor setting
```

## Best Practices

### Do's
✅ Be specific about demographics and representation  
✅ Include technical photography terms  
✅ Specify lighting type and mood  
✅ Add composition techniques  
✅ Mention platform-specific syntax  
✅ Include quality modifiers  
✅ Consider text overlay space  
✅ Test multiple variations  

### Don'ts
❌ Use vague descriptors ("nice", "good", "pretty")  
❌ Forget about negative space for text  
❌ Ignore platform-specific optimization  
❌ Over-stylize for commercial use  
❌ Skip diversity considerations  
❌ Forget technical quality terms  

## Integration Notes

This skill works seamlessly with:
- Brand style guides and requirements
- Platform-specific AI tools and syntax
- Commercial photography standards
- Marketing and content creation workflows
- Image editing and post-processing needs

The goal is always professional, usable results that serve your specific business and creative needs.
