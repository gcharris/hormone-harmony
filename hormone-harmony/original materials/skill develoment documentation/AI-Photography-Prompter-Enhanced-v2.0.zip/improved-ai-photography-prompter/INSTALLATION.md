# AI Photography Prompter (Enhanced) - Installation & Usage Guide

## 🚀 Quick Installation

### Prerequisites
- Node.js 16+ installed on your system
- Gemini API key from [Google AI Studio](https://makersuite.google.com/app/apikey)

### Installation Steps

1. **Install dependencies:**
```bash
npm install
```

2. **Set up configuration:**
```bash
npm run setup
```

3. **Add your API key:**
Edit the `.env` file and replace `your-api-key-here` with your actual Gemini API key.

4. **Test the installation:**
```bash
npm test
```

## 📖 Usage Guide

### 1. Interactive Mode (Recommended for Beginners)

Start the interactive questionnaire:
```bash
npm run interactive
```

The tool will ask you strategic questions about:
- Project type and use case
- Subject matter and demographics  
- Brand style and mood
- Technical requirements
- Platform preferences

**Example session:**
```
🎨 AI Photography Prompter - Enhanced Interactive Mode
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1️⃣  Project type: website-hero
2️⃣  Subject matter: woman practicing morning yoga
3️⃣  Demographics: diverse woman in her 30s, South Asian features
4️⃣  Setting: bright modern living room with large windows
5️⃣  Mood: warm and empowering
6️⃣  Platform: dalle3
7️⃣  Orientation: landscape
8️⃣  Special requirements: space on right side for text overlay
```

### 2. Template Mode (Quick Professional Results)

Use pre-built professional templates:

```bash
# Website hero images
npm run template:hero

# Product lifestyle shots  
npm run template:product

# Social media content
npm run template:social

# Testimonial portraits
npm run template:testimonial

# Before/after transformations
npm run template:before-after

# Overhead flat-lay arrangements
npm run template:flatlay
```

### 3. Direct Prompt Mode (For Experienced Users)

Generate optimized versions of your own prompts:

```bash
npm start "professional photo of a woman working at a modern desk"
```

This will output platform-optimized versions for DALL-E 3, Midjourney, Stable Diffusion, and Gemini Imagen.

### 4. Batch Mode (For Large Projects)

Generate multiple related prompts from a configuration file:

```bash
npm run batch examples/wellness-brand-batch.json
```

Perfect for:
- Complete brand photo sets
- Marketing campaign assets
- Website redesign projects
- Social media content series

## 🎯 Platform-Specific Usage

### DALL-E 3
Best for: General use, photorealistic people, lifestyle scenes
```bash
node generate-image.js "A professional photograph of a confident woman..."
```

### Midjourney
Best for: Artistic quality, consistent aesthetics
```bash
# The tool automatically adds parameters like --ar 16:9 --s 250 --v 6
node generate-image.js "professional lifestyle photography, woman in 30s..."
```

### Stable Diffusion
Best for: Fine control, local generation
```bash
# Automatically adds weighted terms and negative prompts
node generate-image.js "professional photography of a workspace scene"
```

### Gemini Imagen
Best for: Photorealism, diversity, safety-conscious generation
```bash
node generate-image.js "high-quality photograph showing authentic diversity"
```

## 🛠 Advanced Configuration

### Custom Templates

Create your own templates in the `templates/` directory:

```json
{
  "name": "my-custom-template",
  "description": "Description of what this template creates",
  "prompt": "Professional photography of [SUBJECT] in [SETTING]...",
  "variables": ["SUBJECT", "SETTING"],
  "aspectRatio": "16:9"
}
```

### Environment Variables

Customize behavior in your `.env` file:

```bash
# Output directories
IMAGE_OUTPUT_DIR=./my-images
PROMPTS_DIR=./my-prompts

# Default platforms for optimization
DEFAULT_PLATFORMS=dalle3,midjourney,stable-diffusion

# Platform-specific settings
MIDJOURNEY_DEFAULT_AR=16:9
MIDJOURNEY_DEFAULT_STYLIZE=250
SD_DEFAULT_CFG=7
```

### Batch Configuration

Create complex batch jobs with JSON configs:

```json
{
  "name": "My Project",
  "prompts": [
    {
      "name": "hero-image",
      "template": "website-hero",
      "variables": {"MOOD": "professional", "STYLE": "modern"},
      "platforms": ["dalle3", "midjourney"]
    }
  ]
}
```

## 📊 Output and File Management

### Generated Files

The tool creates several types of output:

- **Prompts**: Optimized text prompts for each platform
- **Session Data**: JSON files with your inputs and results
- **Batch Reports**: Comprehensive reports for batch operations

### File Organization

```
generated-images/          # Default output directory
├── latest-prompt.txt      # Most recent prompt (easy copy-paste)
├── interactive_session_*  # Interactive mode sessions
├── batch_*               # Batch operation results
└── quick_prompt_*        # Direct prompt mode results

saved-prompts/            # Prompt library and sessions
├── interactive_*.json    # Full interactive sessions
├── batch_*.json         # Batch operation data
└── templates/           # Custom templates
```

## 🎨 Best Practices

### For Business Users
- Use **interactive mode** for important projects
- Always specify **demographics** for inclusive representation
- Include **negative space** requirements for text overlays
- Test prompts on your **primary platform** first

### For Content Creators
- Build a **template library** for consistent style
- Use **batch mode** for content series
- Specify **aspect ratios** for platform requirements
- Save successful prompts for reuse

### For Agencies
- Create **client-specific templates**
- Use **batch configurations** for project efficiency
- Document **brand guidelines** in template variables
- Maintain **prompt libraries** for different industries

## 🔧 Troubleshooting

### Common Issues

**"API key not found"**
- Check your `.env` file has the correct API key
- Ensure no extra spaces or quotes around the key

**"Template not found"**
- Check template name spelling
- Use `npm run help` to see available templates

**"Batch file error"**
- Validate your JSON syntax
- Check the example file format

**"Low quality results"**
- Add more specific descriptors
- Include professional quality terms
- Try different platforms

### Getting Help

1. **Check the documentation** in this file
2. **Look at example files** in the `examples/` directory  
3. **Use the help command**: `npm run help`
4. **Try interactive mode** for guided assistance

## 📈 Performance Tips

### Optimization Strategies
- **Be specific** about demographics and setting
- **Include lighting** descriptions for better mood
- **Specify composition** techniques for professional framing
- **Add quality modifiers** like "commercial photography"

### Platform Selection
- **DALL-E 3**: Best overall results for most use cases
- **Midjourney**: Choose for artistic, stylized content
- **Stable Diffusion**: Use for fine control and iterations
- **Gemini Imagen**: Ideal for diverse representation

### Batch Efficiency
- **Group similar prompts** in batch files
- **Use templates** for consistency
- **Test individual prompts** before large batches
- **Save successful configurations** for reuse

## 🎯 Success Metrics

Track your success with:
- **First-try success rate** (prompts that work immediately)
- **Platform optimization** (how well prompts perform per platform)
- **Brand consistency** (visual coherence across sets)
- **Time savings** (vs. manual prompt writing)

---

**Ready to create professional AI photography prompts?** Start with `npm run interactive` for the best guided experience!
